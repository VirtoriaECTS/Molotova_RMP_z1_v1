package com.bignerdranch.android.molotova_practica1

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText

class FierdActivity() : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fierd)

        val edittext = findViewById<EditText>(R.id.editText5)
        val edittext2 = findViewById<EditText>(R.id.editText3)

        edittext.isFocusable = false
        edittext.isLongClickable = false
        edittext2.isFocusable = false
        edittext2.isLongClickable = false
        val sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE)

        val name = sharedPreferences.getString("nf", "")
        val value = sharedPreferences.getString("anw", "")

        edittext.setText(name.toString());
        edittext2.setText(value.toString());
    }

    fun peregod(view: View) {
        val intent = Intent(this@FierdActivity, FiesrActiviy::class.java)
        startActivity(intent)
    }
}