package com.bignerdranch.android.molotova_practica1

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.text.InputType
import android.view.View
import android.widget.*

class SecondAcitvity : AppCompatActivity() {

    var nameText : String = "Круг"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second_acitvity)




        val img = findViewById<ImageView>(R.id.imageView)


        val shapeSpinner = findViewById<Spinner>(R.id.vibor)
        shapeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedShape = shapeSpinner.selectedItem.toString()

                if (selectedShape == "Выберите фигуру") {
                    img.setImageResource(R.drawable.figura)
                } else {
                    when (selectedShape) {
                        "Круг" -> {
                            nameText = "Круг"
                            img.setImageResource(R.drawable.figura)
                        }
                        "Треугольник" -> {
                            nameText = "Треугольник"
                            img.setImageResource(R.drawable.figura2)
                        }
                    }

                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }
        }
    }




    fun rachet(view: View) {
        val anwer : Double
        val txt = findViewById<EditText>(R.id.dano)
        val value :String = txt.text.toString()
        if(txt.text.toString().isEmpty()){
            Toast.makeText(this@SecondAcitvity, "Введите данные для расчета", Toast.LENGTH_SHORT).show()
        }
        else{
            if(nameText == "Круг"){

                val arr = value.split(" ").toTypedArray()
                if(arr.count() != 1){
                    Toast.makeText(this@SecondAcitvity, "Необходимо ввести только одно число", Toast.LENGTH_SHORT).show()
                }
                else{
                    try {
                        val p : Double = arr[0].toDouble()
                        if(p <= 0){
                            Toast.makeText(this@SecondAcitvity, "Периметр не может быть меньше или равен нулю", Toast.LENGTH_SHORT).show()
                        }
                        else{
                            anwer = p / (2 * Math.PI)

                            val sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE)
                            val editor: SharedPreferences.Editor = sharedPreferences.edit()

                            editor.putString("nf", nameText)
                            editor.putString("anw", anwer.toString())
                            editor.apply()

                            val intent = Intent(this@SecondAcitvity, FierdActivity()::class.java)
                            startActivity(intent)
                        }

                    }
                    catch (e: NumberFormatException){
                        Toast.makeText(this@SecondAcitvity, "Введите одно число без пробелов", Toast.LENGTH_SHORT).show()
                    }
                }


            }
            else{
                if (nameText == "Треугольник")
                {
                    val arr = value.split(" ").toTypedArray()
                    if(arr.count() != 2){
                        Toast.makeText(this@SecondAcitvity, "Необходимо ввести только два число", Toast.LENGTH_SHORT).show()
                    }
                    else{
                        try {
                            val a : Double = arr[0].toDouble()
                            val b : Double = arr[0].toDouble()
                            if(a <= 0 || b <= 0){
                                Toast.makeText(this@SecondAcitvity, "Стороны треугольника не могут быть меньше или равны нулю", Toast.LENGTH_SHORT).show()
                            }
                            else{
                                anwer = 2 * a + b
                                val sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE)
                                val editor: SharedPreferences.Editor = sharedPreferences.edit()

                                editor.putString("nf", nameText)
                                editor.putString("anw", anwer.toString())
                                editor.apply()
                                val intent = Intent(this@SecondAcitvity, FierdActivity()::class.java)
                                startActivity(intent)
                            }

                        }
                        catch (e: NumberFormatException){
                            Toast.makeText(this@SecondAcitvity, "Введите одно число без пробелов", Toast.LENGTH_SHORT).show()
                        }
                    }

                }
                else{
                    Toast.makeText(this@SecondAcitvity, "Выберите фигуру", Toast.LENGTH_SHORT).show()
                }
            }

        }

    }
    fun getName(): String {
        return  nameText
    }
}



private fun Spinner.adapter(i: Int) {

}


